/*var respuestas = array[4,3,3,3,2,3,4,3,2,4,2,2,3,2,2,2,2,1,2,1,1,2,4,2,2,2,4,2,2,1,1,2,2,4,1,4,1,3,2,3];*/
$(document).ready(function(){
    $("input[type='radio']").click(function(){
    	if($(this).hasClass('bien'))
        	$(this).parent().addClass('correct');
        else
        	$(this).parent().addClass('incorrect');
    });
}); 